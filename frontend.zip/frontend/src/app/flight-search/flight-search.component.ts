import { FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../services/customer.service';

@Component({
  selector: 'app-flight-search',
  templateUrl: './flight-search.component.html',
  styleUrls: ['./flight-search.component.css']
})
export class FlightSearchComponent implements OnInit {
  fullName;
  test;

  foods= [
    {value: 'BANGALORE', viewValue: 'bangalore'},
    {value: 'DELHI', viewValue: 'delhi'},
    {value: 'MUMBAI', viewValue: 'mumbai'},
    {value: 'CHENNAI', viewValue: 'chennai'},
    {value: 'PUNE', viewValue: 'pune'},
    {value: 'HYDERABAD', viewValue: 'hyderabad'},
    {value: 'PATNA', viewValue: 'patna'},
    {value: 'KOLKATA', viewValue: 'Kolkata'}
  
  ];
  constructor(private _router:Router,private fb:FormBuilder) { }
  searchFlight=this.fb.group({
    from:['',Validators.required],
    to:['',Validators.required],
    travelDate:['',Validators.required],
    returnDate:['']

  
  });
  ngOnInit(): void {
  }

  fu(){
    this.test=this.fullName.getDate();
    console.log(this.test);

  }

  forward(){
    this._router.navigate(['twowayflight']);
  }
  my(){
    console.log("this");
  }
  singleFlight(){

  }
  eco(){
    console.log("eco");
    console.log(this.fullName)

  }
  busi(){
    console.log("busi ")

  }
  
  search(){
    let departureDate:Date = this.searchFlight.controls.travelDate.value;
    let travelDate = departureDate.getFullYear()+"-"+("0"+(departureDate.getMonth()+1)).slice(-2)+"-"+("0"+departureDate.getDate()).slice(-2);
    let source= this.searchFlight.controls.from.value;
    let destination = this.searchFlight.controls.to.value;

    localStorage.setItem("travelDate",travelDate);
    localStorage.setItem("source",source);
    localStorage.setItem("destination",destination);
    console.log(typeof this.searchFlight.controls.returnDate.value.getMonth,"svdv");
     if(this.searchFlight.controls.returnDate.value.getMonth!=null){
       //localStorage.setItem("twoWay")
      let departureDate:Date = this.searchFlight.controls.returnDate.value;
      let returnDate = departureDate.getFullYear()+"-"+("0"+(departureDate.getMonth()+1)).slice(-2)+"-"+("0"+departureDate.getDate()).slice(-2);
      localStorage.setItem("returnDate",returnDate);
       this._router.navigate(['twowayflight']);
       return ;
     }
    this._router.navigate(['flighselect']);

  }
 

}