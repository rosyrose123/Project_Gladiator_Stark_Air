package com.lti.service;

public interface PassengerService {
	

}
