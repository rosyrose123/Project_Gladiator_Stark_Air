import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirm-log-out',
  templateUrl: './confirm-log-out.component.html',
  styleUrls: ['./confirm-log-out.component.css']
})
export class ConfirmLogOutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
