package com.lti.service;

import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.springframework.stereotype.Service;

@Service("ticketGenerationService")
public class TicketGenerationService {
	public void generateTicket(String flightNumber, String bookingId, String source, String destination, String name,
			String age, String dateTime, String sex, int call) {
		try {
			PDDocument pDDocument = PDDocument.load(new File("C:/Users/siddh/Desktop/gladiator 12/Template.pdf"));
			PDAcroForm pDAcroForm = pDDocument.getDocumentCatalog().getAcroForm();
			PDField field = pDAcroForm.getField("Name");
			field.setValue(name);
			field = pDAcroForm.getField("Age");
			field.setValue(age);
			field = pDAcroForm.getField("Sex");
			field.setValue(sex);
			field = pDAcroForm.getField("Flight_Number");
			field.setValue(flightNumber);
			field = pDAcroForm.getField("Booking_Id");
			field.setValue(bookingId);
			field = pDAcroForm.getField("Source");
			field.setValue(source);
			field = pDAcroForm.getField("Destination");
			field.setValue(destination);
			field = pDAcroForm.getField("Date_Time");
			field.setValue(dateTime);
			field = pDAcroForm.getField("Name_Alt");
			field.setValue(name);
			field = pDAcroForm.getField("Flight_Number_Alt");
			field.setValue(flightNumber);
			field = pDAcroForm.getField("Booking_Id_Alt");
			field.setValue(bookingId);
			field = pDAcroForm.getField("Date_Time_Alt");
			field.setValue(dateTime);
			pDAcroForm.refreshAppearances();
			pDAcroForm.flatten();
			pDDocument.save("C:/Users/siddh/Desktop/gladiator 12/Generated Ticket/"+bookingId+"Passenger"+call+".pdf");
			pDDocument.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

