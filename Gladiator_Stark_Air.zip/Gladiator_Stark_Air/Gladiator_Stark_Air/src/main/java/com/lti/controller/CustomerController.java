package com.lti.controller;

import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.Customer;
import com.lti.model.Flight;
import com.lti.model.FlightID;
import com.lti.model.OTPSystem;
import com.lti.model.PassengerDetails;
import com.lti.service.CustomerService;
import com.lti.service.FlightService;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

@RestController
@RequestMapping(path = "customer")
@CrossOrigin
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	@Autowired
	private FlightService flightService;
	
	private Map<String, OTPSystem> otp_data = new HashMap<String, OTPSystem>();

	private final static String ACCOUNT_SID = "AC104b82fdd1715caf7de75ce8c5f4b86a";
	private final static String AUTH_ID = "39adf329c1c40169717653eaf739e0d6";

	static {
		Twilio.init(ACCOUNT_SID, AUTH_ID);
	}
	
	@PostMapping(path="/mobilenumbers/{email}")
	public Boolean sendOTP(@PathVariable("email") String email)
	{	
		if(customerService.findCustomerById(email)!=null)
		{
			OTPSystem otpSystem= new OTPSystem();
			otpSystem.setMobileNumber(customerService.findCustomerById(email).getPhoneNumber());
			otpSystem.setOtp(String.valueOf(((int)(Math.random()*(10000 - 1000))) + 1000));
			otpSystem.setExpiryTime(System.currentTimeMillis()+90000);
			otp_data.put(customerService.findCustomerById(email).getPhoneNumber(), otpSystem);
			Message.creator(new PhoneNumber(customerService.findCustomerById(email).getPhoneNumber()), new PhoneNumber("+13344714435"), "Your OTP is : "+otpSystem.getOtp()).create();
			System.out.println("OTP sent successfully");
			return true;
		}
		System.out.println("Failed to sent OTP");
		return false;
	}

	@PutMapping(path = "/mobilenumbers/{email}")
	public Boolean verifyOTP(@PathVariable("email") String email,
			@RequestBody OTPSystem requestOTPSystem) {
		if (requestOTPSystem.getOtp() == null || requestOTPSystem.getOtp().trim().length() <= 0) {
			System.out.println("Please enter OTP");
			return false;
		}

		if (otp_data.containsKey(customerService.findCustomerById(email).getPhoneNumber())) {
			OTPSystem otpSystem = otp_data.get(customerService.findCustomerById(email).getPhoneNumber());
			if (otpSystem != null) {
				if (otpSystem.getExpiryTime() >= System.currentTimeMillis()) {
					if (requestOTPSystem.getOtp().equals(otpSystem.getOtp())) {
						System.out.println("OTP is Verified");
						return true;
					}
				}
			}
		}
		System.out.println("OTP verification failed");
		return false;
	}
	
	@PostMapping(path = "/register")
	public void addCustomer(@RequestBody Customer customer)
	{
		customerService.addCustomer(customer);
	}

	@GetMapping(path = "/{emailId}/{password}")
	public String customerLoginAuthentication(@PathVariable("emailId") String emailId,
			@PathVariable("password") String password) {
		return customerService.customerLoginAuthentication(emailId, password);
	}

	@PostMapping(path = "/{travelDate}/{source}/{destination}")
	public List<Flight> searchFlight(@PathVariable("travelDate") Date travelDate, @PathVariable("source") String source,
			@PathVariable("destination") String destination) {
		return flightService.findFlightByCustomer(travelDate, source, destination);
	}
	
	@PutMapping(path ="/update")
	public Customer updateCustomer(@RequestBody Customer customer)
	{
		//return customer;
		boolean result=customerService.modifyCustomer(customer);
		if(result)
			customer=customerService.findCustomerById(customer.getEmailId());
		return customer;
	}

}