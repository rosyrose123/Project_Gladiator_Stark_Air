import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbare',
  templateUrl: './navbare.component.html',
  styleUrls: ['./navbare.component.css']
})
export class NavbareComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
