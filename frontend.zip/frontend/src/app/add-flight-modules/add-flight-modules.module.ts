import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


const BaseComponents=[
  
  
];

@NgModule({
 
  imports: [
    BaseComponents
  ],
  exports:[
    BaseComponents
  ]
})
export class AddFlightModulesModule { }
