package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import com.lti.model.FlightBooked;
import com.lti.model.PassengerDetails;

@Repository("flightBookedDao")
public class FlightBookedDaoImpl implements FlightBookedDao {


	@PersistenceContext
	EntityManager entityManager;
	
	
	@Override
	public List<FlightBooked> readAllFlightBooked() {
		String jpql ="Select f from FlightBooked f where f.adminCancellationStatus=0 && f.customerCancellationStatus=0";
		TypedQuery<FlightBooked> tquery = entityManager.createQuery(jpql, FlightBooked.class);
		return tquery.getResultList();
	}

	@Override
	@Transactional(propagation = Propagation.MANDATORY)
	public int deleteFlightBookedByCustomer(String bookingId) {
		FlightBooked fb = entityManager.find(FlightBooked.class, bookingId);
		System.out.println(fb);
		
		if(fb!=null && fb.getCustomerCancelledStatus()==0)
		{
			fb.setCustomerCancelledStatus(1);
			entityManager.merge(fb);
			return 1;
		}
		else
			return 0;
	}
	
	@Override
	public FlightBooked readFlightBookedById(String bookingId) {
		
		return entityManager.find(FlightBooked.class, bookingId);
	}

	@Override
	public FlightBooked addPassengerDetails(PassengerDetails details, String bookingId) {
		FlightBooked fb = readFlightBookedById(bookingId);
		fb.addDetails(details);
		return fb;
	}

}
